import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { InsertUser, apiRequests, pageViews, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      const client = postgres(process.env.DATABASE_URL, { max: 1 });
      _db = drizzle(client);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

    await db.insert(users).values(values).onConflictDoUpdate({
      target: users.openId,
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot get user: database not available"); return undefined; }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

/** Track a page view — fire-and-forget, never throws */
export async function trackPageView(path: string, referrer?: string, userAgent?: string) {
  try {
    const db = await getDb();
    if (!db) return;
    await db.insert(pageViews).values({ path, referrer: referrer ?? null, userAgent: userAgent ?? null });
  } catch { /* silent */ }
}

/** Track an API request — fire-and-forget, never throws */
export async function trackApiRequest(opts: {
  endpoint: string;
  targetUrl?: string;
  status: number;
  durationMs?: number;
  filesCount?: number;
  totalBytes?: number;
}) {
  try {
    const db = await getDb();
    if (!db) return;
    await db.insert(apiRequests).values({
      endpoint: opts.endpoint,
      targetUrl: opts.targetUrl ?? null,
      status: opts.status,
      durationMs: opts.durationMs ?? null,
      filesCount: opts.filesCount ?? null,
      totalBytes: opts.totalBytes ?? null,
    });
  } catch { /* silent */ }
}

/** Get usage stats for the dashboard */
export async function getUsageStats() {
  try {
    const db = await getDb();
    if (!db) return null;
    const [pvResult, apiResult] = await Promise.all([
      db.select().from(pageViews),
      db.select().from(apiRequests),
    ]);
    return {
      totalPageViews: pvResult.length,
      totalApiRequests: apiResult.length,
      successfulCrawls: apiResult.filter(r => r.status === 200).length,
    };
  } catch { return null; }
}
